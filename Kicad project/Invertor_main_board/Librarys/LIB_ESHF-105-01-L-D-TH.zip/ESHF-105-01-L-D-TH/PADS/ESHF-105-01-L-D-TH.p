*PADS-LIBRARY-PART-TYPES-V9*

ESHF-105-01-L-D-TH ESHF10501LDTH I CON 9 1 0 0 0
TIMESTAMP 2025.10.18.15.24.54
"Manufacturer_Name" SAMTEC
"Manufacturer_Part_Number" ESHF-105-01-L-D-TH
"Mouser Part Number" 200-ESHF10501LDTH
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Samtec/ESHF-105-01-L-D-TH?qs=%252BZP6%2F%252BtExtA76X6DwKXxNw%3D%3D
"Arrow Part Number" ESHF-105-01-L-D-TH
"Arrow Price/Stock" https://www.arrow.com/en/products/eshf-105-01-l-d-th/samtec?region=nac
"Description" .050" Shrouded Terminal Strip For FFSD, through hole, dual row,  positions per row
"Datasheet Link" http://suddendocs.samtec.com/prints/shf-1xx-01-x-d-xx-xx-mkt.pdf
"Geometry.Height" 5.33mm
GATE 1 10 0
ESHF-105-01-L-D-TH
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
684866/786831/2.50/10/4/Connector
